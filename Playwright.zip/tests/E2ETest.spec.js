require('dotenv').config();
const { test, expect } = require('@playwright/test');

test.describe('Salesforce E2E Tests', () => {
  test('Login and Create Account', async ({ page }) => {
    // Step 1: Navigate to Salesforce login page
    await page.goto(process.env.SF_URL);

    // Step 2: Log in to Salesforce
    await page.fill('#username', process.env.SF_USERNAME);
    await page.fill('#password', process.env.SF_PASSWORD);
    await page.click('#Login');
    await page.waitForNavigation();

    // Assert successful login by checking the URL
    expect(page.url()).toContain('/lightning/');

    await page.getByRole('button', { name: 'App Launcher' }).click();
    await page.getByPlaceholder('Search apps and items...').fill('sales');
    await page.getByRole('option', { name: 'Sales', exact: true }).click();
    await page.getByRole('link', { name: 'Accounts' }).click();
    await page.getByRole('button', { name: 'New' }).click();
    await page.getByLabel('*Account Name').click();
    await page.getByLabel('*Account Name').fill('TestAccount1');
    await page.getByRole('button', { name: 'Save', exact: true }).click();

  });
});
