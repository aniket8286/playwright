require('dotenv').config();
const { test, expect } = require('@playwright/test');

test('Salesforce login and navigation', async ({ page }) => {
  // Login
  await page.goto('https://login.salesforce.com/');
  await page.getByLabel('Username').fill(process.env.SF_USERNAME);
  await page.getByLabel('Password').fill( process.env.SF_PASSWORD);
  await page.getByRole('button', { name: 'Log In' }).click();

  // Navigation
  await page.getByRole('button', { name: 'App Launcher' }).click();
  await page.getByPlaceholder('Search apps and items...').fill('test');
  await page.getByRole('option', { name: 'Test2', exact: true }).click();
  await page.locator('div').filter({ hasText: /^StdClassNames List$/ }).dblclick();
  await page.getByRole('link', { name: 'Candidates' }).click();
  await page.getByRole('link', { name: 'Classes' }).click();
  await page.getByRole('link', { name: 'FlexiDash' }).click();
});
