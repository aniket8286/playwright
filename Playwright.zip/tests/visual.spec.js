require('dotenv').config();
const { test, expect } = require('@playwright/test');
const { getSalesforceToken } = require('../helpers/auth-helper');

test.describe('Salesforce Visual Tests', () => {
  let accessToken;

  // Fetch Salesforce access token before all tests
  test.beforeAll(async () => {
    accessToken = await getSalesforceToken();
  });

  test('Login Page Visual Test', async ({ page }) => {
    // Navigate to Salesforce login page
    await page.goto(process.env.SF_URL);

    // Take a screenshot of the login page
    const loginScreenshot = await page.screenshot();

    // Compare with the baseline screenshot
    // The baseline image will be saved in the __image_snapshots__ directory by default
    expect(loginScreenshot).toMatchSnapshot('login-page-baseline.png');
  });

  test('Account Creation Page Visual Test', async ({ page }) => {
    // Navigate to Salesforce account creation page
    await page.goto(`${process.env.SF_URL}/lightning/page/home`);

    // Log in to Salesforce (if necessary for the page to load)
    await page.fill('#username', process.env.SF_USERNAME);
    await page.fill('#password', process.env.SF_PASSWORD);
    await page.click('#Login');
    await page.waitForNavigation();

    // Take a screenshot of the account creation page
    const accountCreationScreenshot = await page.screenshot();

    // Compare with the baseline screenshot
    expect(accountCreationScreenshot).toMatchSnapshot('account-creation-page-baseline.png');
  });
});
