import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
 await page.goto('https://login.salesforce.com/');
 await page.getByLabel('Username').click();
 await page.getByLabel('Username').fill('aniketchauhan8286@gmail.com');
 await page.getByLabel('Password').click();
 await page.getByLabel('Password').fill('aniket8286@');
 await page.getByRole('button', { name: 'Log In' }).click();
 await page.getByRole('button', { name: 'App Launcher' }).click();
 await page.getByPlaceholder('Search apps and items...').fill('sales');
 await page.getByRole('option', { name: 'Sales', exact: true }).click();
 await page.getByRole('link', { name: 'Accounts' }).click();
 await page.getByRole('button', { name: 'New' }).click();
 await page.getByLabel('*Account Name').click();
 await page.getByLabel('*Account Name').fill('T');
 await page.getByRole('button', { name: 'Save', exact: true }).click();
});