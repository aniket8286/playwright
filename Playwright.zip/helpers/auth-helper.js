const express = require('express');
const axios = require('axios');
require('dotenv').config();

const app = express();
const port = 3000;

// Step 1: Redirect user to Salesforce OAuth authorization URL
app.get('/login', (req, res) => {
  const authorizationUrl = `${process.env.SF_LOGIN_URL}/services/oauth2/authorize?response_type=code&client_id=${process.env.SF_CLIENT_ID}&redirect_uri=${process.env.SF_REDIRECT_URI}`;
  res.redirect(authorizationUrl);
});

// Step 2: Handle the callback after the user authorizes the app
app.get('/callback', async (req, res) => {
  const authorizationCode = req.query.code;

  // Exchange the authorization code for an access token
  try {
    const response = await axios.post(`${process.env.SF_LOGIN_URL}/services/oauth2/token`, null, {
      params: {
        grant_type: 'authorization_code',
        client_id: process.env.SF_CLIENT_ID,
        client_secret: process.env.SF_CLIENT_SECRET,
        code: authorizationCode,
        redirect_uri: process.env.SF_REDIRECT_URI,
      },
    });

    const accessToken = response.data.access_token;
    res.send(`Access token: ${accessToken}`);
  } catch (error) {
    console.error('Error during authentication:', error);
    res.status(500).send('Authentication failed');
  }
});

app.listen(port, () => {
  console.log(`App running at http://localhost:${port}`);
});
