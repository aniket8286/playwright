require('dotenv').config();
const { defineConfig } = require('@playwright/test');

module.exports = defineConfig({
  testDir: './tests', // Base directory for all tests
  retries: 1, // Retry failed tests once (helpful for flaky tests)
  timeout: 60000, // Timeout of 60 seconds for each test
  projects: [
    {
      name: 'test', // End-to-end test project
      testDir: '/home/cmss/Desktop/playWrigth/tests', // Directory for E2E tests
    },
    // {
    //   name: 'login',
    //   testDir: './tests/login.spec.js', // Correct file path for login.spec.js
    // },
    // {
    //   name: 'api', // API test project
    //   testDir: './tests/api', // Directory for API tests
    // },
    // {
    //   name: 'visual', // Visual regression test project
    //   testDir: './tests/visual', // Directory for visual tests
    // },
  ],
  reporter: [
    ['list'], // Console reporter (basic output)
    ['html', { outputFolder: 'test-results' }], // HTML reporter for detailed report
  ],
  use: {
    baseURL: process.env.SF_URL, // Salesforce base URL from environment variables
    headless: true, // Run tests in headless mode (i.e., without UI)
    screenshot: 'only-on-failure', // Capture screenshots only on failure
    trace: 'retain-on-failure', // Retain trace logs on failure for debugging
  },
});
